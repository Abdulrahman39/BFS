
public  class EdgeNode {
    public int v;
    public int weight;

    public EdgeNode(int v, int weight) {
        this.v = v;
        this.weight = weight;
    }
}

