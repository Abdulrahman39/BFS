
import java.util.*;

public class Graph <T> implements GraphInterface
{
    public int numVertices;
    public int numEdges; 
    public ArrayList<LinkedList<EdgeNode>> edges; 
    public ArrayList<Integer> degrees; 
    public ArrayList<Integer> parent;
    public boolean directed; 
    
    public Graph(boolean directed)
    {
       numVertices = 0;
       numEdges = 0; 
       edges = new ArrayList<LinkedList<EdgeNode>>(); 
       degrees = new ArrayList<Integer>(); 
       parent = new ArrayList<Integer>();
       this.directed = directed; 
   }
    
   public void readGraph()
   {
       System.out.println("Enter number of vertices of your graph: ");
       Scanner in = new Scanner(System.in);
       numVertices = in.nextInt(); 
       for (int i=0; i<numVertices; i++)
       {
          edges.add(new LinkedList<EdgeNode>());
          degrees.add(0);
          parent.add(-1);
       }
       System.out.println("Enter number of edges of your graph: ");
       numEdges = in.nextInt();
       System.out.println("Enter each edge: ");
       for(int i=0; i<numEdges; i++)
       {
           int v1 = in.nextInt();
           int v2 = in.nextInt();
           int w = in.nextInt();
           insertEdge(v1, v2, w);
           degrees.set(v1, degrees.get(v1)+1);
           if(!directed)
           {
               degrees.set(v2, degrees.get(v2)+1);
              insertEdge(v2, v1, 1);
           }
       }
   }   
   
   private void insertEdge(int v1, int v2, int weight)
   {
       EdgeNode e = new EdgeNode(v2, weight);
       edges.get(v1).add(e);
   }
   
   private void initializeParent()
   {
       parent = new ArrayList<Integer>();
       for (int i=0; i<numVertices; i++)
          parent.add(-1);
   }
   
   public void BFS(int start)
   {
       initializeParent();
       System.out.println("BFS Traversal: ");
       Queue<Integer> Q = new LinkedList();
       char[] status = new char[numVertices];
       for(int i=0; i<numVertices; i++)
           status[i] = 'u';  // undiscovered status 
       Q.add(start); 
       status[start] = 'd';  // discovered status
       while (!Q.isEmpty())
       {
           int v = Q.remove();  // early processing for vertex v 
           System.out.println("start from " + v);
          Arrays.sort(new LinkedList[]{edges.get(v)});
           for(int j=0; j<degrees.get(v);j++)
           {
               int adj = edges.get(v).get(j).v;

               if (parent.get(adj)!=-1 ) {
                   LinkedList<EdgeNode> a = edges.get(parent.get(adj));
                   for (int i = 0; i <a.size() ; i++) {
                       if (a.get(i).v==adj) {
                           EdgeNode p = a.get(i);
                           int adjw = edges.get(v).get(j).weight;
                           if (adjw<p.weight)
                               parent.set(adj, v);
                           break;
                       }
                   }


               }

                   if (status[adj] == 'u') {
                       Q.add(adj);
                       parent.set(adj, v);  // track the parent of the discovered vertex
                       status[adj] = 'd';
                       System.out.println(adj + " discovered");
                   }

               if(status[adj] != 'p' || directed)
                   System.out.println("Edge ("+v+","+adj+") is processed ");  // processing an edge
           }
           status[v] = 'p';   // processed status
           System.out.println(v+" processed");   // late processing for vertex v 
       } 
       System.out.println("");
   }
   
   public void shortestPathBFS(int s, int e) // find shortest path from vertext s to vertex e (unweighted) 
   {
       BFS(s); 
       System.out.print("Shortest Path from " + s + " to " + e + ": ");
       shortestPathBFS1(s,e);
   }
   
   private void shortestPathBFS1(int s, int e)
   {
       if(s == e || e == -1)   
           System.out.print(s + " ");
       else 
       {
           shortestPathBFS1(s, parent.get(e));
           System.out.print(e + " ");
       }
   }
   
   public void DFS(int start)
   {
       initializeParent();
       System.out.println("DFS Traversal: ");
       char[] status = new char[numVertices];
       for(int i=0; i<numVertices; i++)
           status[i] = 'u';  // undiscovered status
       status[start] = 'd';
       DFS1(start, status);
   }
   
   private void DFS1(int start, char []status)
   {
       if(status[start] == 'p')
       {
           System.out.println("");
           return;
       }
       System.out.println("start from " + start);
       Arrays.sort(new LinkedList[]{edges.get(start)});
       for(int i=0; i<degrees.get(start); i++)
       {
           int adj = edges.get(start).get(i).v;
           if(status[adj] == 'u')
           {
               status[adj] = 'd';
               parent.set(adj, start);
               System.out.println(adj + " discovered");
               System.out.println("Edge ("+start+","+adj+") is processed ");  // processing an edge
               DFS1(adj,status);
           }
           else if((status[adj] != 'p' && parent.get(start) != adj )|| directed)
                  System.out.println("Edge ("+start+","+adj+") is processed ");  // processing an edge
       }
       status[start] = 'p';
       System.out.println(start+" processed");   // late processing for vertex start

   }
      
   public void displayGraph()
   {
       for(int i=0; i<numVertices; i++)
       {
           System.out.println("Node: " + i);
           System.out.println("Degree: " + degrees.get(i));
           System.out.println("Connected to: ");
           for(int j=0; j<edges.get(i).size(); j++)
               System.out.println("(v:"+edges.get(i).get(j).v+",w:"+edges.get(i).get(j).weight+")");
       }
   }
}
   
   
    
    
    
    