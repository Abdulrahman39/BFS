
import java.util.ArrayList;

public interface GraphInterface
{ 
    void readGraph(); 
    void BFS(int start);
    void shortestPathBFS(int s, int e);
   // void DFS(int start);
}
