


public class GraphDS 
{
    public static void main(String[] args) 
    {
        Graph G = new Graph(true);
        G.readGraph();
        //G.displayGraph();
        //G.BFS(0);
        G.shortestPathBFS(0, 3);
        //G.DFS(1);
    }
}
